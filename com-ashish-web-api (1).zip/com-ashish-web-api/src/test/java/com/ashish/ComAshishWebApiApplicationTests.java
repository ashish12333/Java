package com.ashish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComAshishWebApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
