package com.ashish.service;

import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.ashish.dto.FacilityDTO;
import com.ashish.dto.TransportDTO;
import com.ashish.entity.TransportEntity;
import com.ashish.mapper.TransportMapper;
import com.ashish.repository.TransportRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

class TransportServiceImplTest {

    @Mock
    private TransportRepository transportRepository;

    @InjectMocks
    private TransportServiceImpl transportService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveTransportPositive() {
        TransportDTO transportDTO = getTransportDTO(); // Mock data
        TransportEntity transportEntity = new TransportEntity(); // Mock data
        transportEntity.setNoOfTrucks(1);
        transportEntity.setWeight(100.0);
        when(transportRepository.save(any(TransportEntity.class))).thenReturn(transportEntity);
        TransportDTO result = transportService.saveTransport(transportDTO);
        assertThat(result.getNoOfTrucks()).isEqualTo(result.getNoOfTrucks());
        assertThat(result.getWeight()).isEqualTo(result.getWeight());
    }

    @Test
    void testSaveTransportNegative() {
        TransportDTO transportDTO = getTransportDTO();
        when(transportRepository.save(any(TransportEntity.class))).thenThrow(new RuntimeException("Save failed"));

        try {
            transportService.saveTransport(transportDTO);
        } catch (RuntimeException e) {
            assertThat(e.getMessage()).isEqualTo("Save failed");
        }
    }

    @Test
    void testGetTransportPositive() {
        List<TransportEntity> transportEntities = Arrays.asList(new TransportEntity(), new TransportEntity());
        when(transportRepository.findByShipperIdOrTruckTypeOrProductTypeOrLoadingPointOrUnloadingPoint(
                "shipper1", "truck1", "product1", "loading1", "unloading1"))
                .thenReturn(transportEntities);
        List<TransportDTO> result = transportService.getTransport("shipper1", "truck1", "product1", "loading1", "unloading1");
        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(2);
    }

    @Test
    void testGetTransportNegative() {
        when(transportRepository.findByShipperIdOrTruckTypeOrProductTypeOrLoadingPointOrUnloadingPoint(
                "shipper1", "truck1", "product1", "loading1", "unloading1"))
                .thenThrow(new RuntimeException("Transport not found"));

        try {
            transportService.getTransport("shipper1", "truck1", "product1", "loading1", "unloading1");
        } catch (RuntimeException e) {
            assertThat(e.getMessage()).isEqualTo("Transport not found");
        }
    }

    @Test
    void testGetTransportByIdPositive() {
        TransportEntity transportEntity = new TransportEntity();
        transportEntity.setLoadId("1234567890");
        when(transportRepository.findById("loadId1")).thenReturn(Optional.of(transportEntity));
        TransportDTO result = transportService.getTransportById("loadId1");
        assertThat(result.getLoadId()).isEqualTo("1234567890");
    }

    @Test
    void testGetTransportByIdNegative() {
        when(transportRepository.findById("loadId1")).thenReturn(Optional.empty());

        TransportDTO result = transportService.getTransportById("loadId1");

        assertThat(result).isNotNull(); // Default DTO returned
    }

    @Test
    void testUpdateTransportByIdPositive() {
        TransportDTO transportDTO = getTransportDTO();
        TransportEntity transportEntity = new TransportEntity();
        when(transportRepository.save(any(TransportEntity.class))).thenReturn(transportEntity);
        TransportDTO result = transportService.updateTransportById("1234567", transportDTO);
        assertNotNull(result);
    }

    @Test
    void testUpdateTransportByIdNegative() {
        TransportDTO transportDTO = new TransportDTO();
        transportDTO.setLoadId("differentId");

        try {
            transportService.updateTransportById("loadId1", transportDTO);
        } catch (RuntimeException e) {
            assertThat(e.getMessage()).isEqualTo("loadId1 loadId not found");
        }
    }

    @Test
    void testDeleteTransportByIdPositive() {
        doNothing().when(transportRepository).deleteById("loadId1");

        transportService.daleteTransportById("loadId1");

        verify(transportRepository, times(1)).deleteById("loadId1");
    }

    @Test
    void testDeleteTransportByIdNegative() {
        doThrow(new RuntimeException("Delete failed")).when(transportRepository).deleteById("loadId1");

        try {
            transportService.daleteTransportById("loadId1");
        } catch (RuntimeException e) {
            assertThat(e.getMessage()).isEqualTo("Delete failed");
        }
    }
    
    private TransportDTO getTransportDTO() {
    	return new TransportDTO("1234567", new FacilityDTO("Delhi", "Mumbai", LocalDate.now(), LocalDate.now()), "Toy", "Mini", 1, 100.00, "testing ", "12345", LocalDate.now());
    }
}
