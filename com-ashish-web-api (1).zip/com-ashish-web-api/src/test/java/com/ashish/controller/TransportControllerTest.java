package com.ashish.controller;

import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.ashish.dto.TransportDTO;
import com.ashish.service.TransportService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Arrays;

class TransportControllerTest {

	@Mock
	private TransportService transportService;

	@InjectMocks
	private TransportController transportController;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testSaveTransportPositive() {
		TransportDTO transportDTO = new TransportDTO(); // Provide necessary mock fields.
		when(transportService.saveTransport(transportDTO)).thenReturn(transportDTO);

		ResponseEntity<TransportDTO> response = transportController.saveTransport(transportDTO);

		assertThat(response.getBody()).isEqualTo(transportDTO);
		assertThat(response.getStatusCode().value()).isEqualTo(201);
	}

	@Test
	void testSaveTransportNegative() {
		TransportDTO transportDTO = new TransportDTO(); // Provide necessary mock fields.
		when(transportService.saveTransport(transportDTO)).thenThrow(new RuntimeException("Error saving transport"));

		try {
			transportController.saveTransport(transportDTO);
		} catch (RuntimeException e) {
			assertThat(e.getMessage()).isEqualTo("Error saving transport");
		}
	}

	@Test
	void testGetTransportPositive() {
		List<TransportDTO> transportList = Arrays.asList(new TransportDTO(), new TransportDTO()); // Mock data.
		when(transportService.getTransport("shipper1", "truckType1", "productType1", "loadingPoint1",
				"unloadingPoint1")).thenReturn(transportList);

		ResponseEntity<List<TransportDTO>> response = transportController.getTransport("shipper1", "truckType1",
				"productType1", "loadingPoint1", "unloadingPoint1");

		assertThat(response.getBody()).isEqualTo(transportList);
	}

	@Test
	void testGetTransportNegative() {
		when(transportService.getTransport("shipper1", "truckType1", "productType1", "loadingPoint1",
				"unloadingPoint1")).thenThrow(new RuntimeException("No transports found"));

		try {
			transportController.getTransport("shipper1", "truckType1", "productType1", "loadingPoint1",
					"unloadingPoint1");
		} catch (RuntimeException e) {
			assertThat(e.getMessage()).isEqualTo("No transports found");
		}
	}

	@Test
	void testGetTransportByIdPositive() {
		TransportDTO transportDTO = new TransportDTO(); // Provide necessary mock fields.
		when(transportService.getTransportById("loadId1")).thenReturn(transportDTO);

		ResponseEntity<TransportDTO> response = transportController.getTransportById("loadId1");

		assertThat(response.getBody()).isEqualTo(transportDTO);
	}

	@Test
	void testGetTransportByIdNegative() {
		when(transportService.getTransportById("loadId1")).thenThrow(new RuntimeException("Transport not found"));

		try {
			transportController.getTransportById("loadId1");
		} catch (RuntimeException e) {
			assertThat(e.getMessage()).isEqualTo("Transport not found");
		}
	}

	@Test
	void testUpdateTransportByIdPositive() {
		TransportDTO transportDTO = new TransportDTO(); // Provide necessary mock fields.
		when(transportService.updateTransportById("loadId1", transportDTO)).thenReturn(transportDTO);

		ResponseEntity<TransportDTO> response = transportController.updateTransportById("loadId1", transportDTO);

		assertThat(response.getBody()).isEqualTo(transportDTO);
	}

	@Test
	void testUpdateTransportByIdNegative() {
		TransportDTO transportDTO = new TransportDTO(); // Provide necessary mock fields.
		when(transportService.updateTransportById("loadId1", transportDTO))
				.thenThrow(new RuntimeException("Error updating transport"));

		try {
			transportController.updateTransportById("loadId1", transportDTO);
		} catch (RuntimeException e) {
			assertThat(e.getMessage()).isEqualTo("Error updating transport");
		}
	}

	@Test
	void testDeleteTransportByIdPositive() {
		doNothing().when(transportService).daleteTransportById("loadId1");

		transportController.daleteTransportById("loadId1");

		verify(transportService, times(1)).daleteTransportById("loadId1");
	}

	@Test
	void testDeleteTransportByIdNegative() {
		doThrow(new RuntimeException("Error deleting transport")).when(transportService).daleteTransportById("loadId1");

		try {
			transportController.daleteTransportById("loadId1");
		} catch (RuntimeException e) {
			assertThat(e.getMessage()).isEqualTo("Error deleting transport");
		}
	}
}
