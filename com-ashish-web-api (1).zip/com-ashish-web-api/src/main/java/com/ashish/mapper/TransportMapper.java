package com.ashish.mapper;

import com.ashish.dto.FacilityDTO;
import com.ashish.dto.TransportDTO;
import com.ashish.entity.TransportEntity;

public class TransportMapper {

	public static TransportEntity mapTransportDTOToTransportEntity(TransportDTO transportDTO) {
		FacilityDTO facilityDTO = transportDTO.getFacility();
		return new TransportEntity(transportDTO.getLoadId(), facilityDTO.getLoadingPoint(),
				facilityDTO.getUnloadingPoint(), facilityDTO.getLoadingDate(), facilityDTO.getUnloadingDate(),
				transportDTO.getProductType(), transportDTO.getTruckType(), transportDTO.getNoOfTrucks(),
				transportDTO.getWeight(), transportDTO.getComment(), transportDTO.getShipperId(),
				transportDTO.getDate());
	}

	public static TransportDTO mapTransportEntityToTransportDTO(TransportEntity transportEntity) {
		FacilityDTO facilityDTO = new FacilityDTO(transportEntity.getLoadingPoint(),
				transportEntity.getUnloadingPoint(), transportEntity.getLoadingDate(),
				transportEntity.getUnloadingDate());
		return new TransportDTO(transportEntity.getLoadId(), facilityDTO, transportEntity.getProductType(),
				transportEntity.getTruckType(), transportEntity.getNoOfTrucks(), transportEntity.getWeight(),
				transportEntity.getComment(), transportEntity.getShipperId(), transportEntity.getDate());
	}
}
