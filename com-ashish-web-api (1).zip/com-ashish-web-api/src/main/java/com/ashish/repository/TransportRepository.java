package com.ashish.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ashish.entity.TransportEntity;

@Repository
public interface TransportRepository extends CrudRepository<TransportEntity, String> {
	public List<TransportEntity> findByShipperIdOrTruckTypeOrProductTypeOrLoadingPointOrUnloadingPoint(String shipperId,
			String truckType, String productType, String loadingPoint, String unloadingPoint);
}
