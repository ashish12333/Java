package com.ashish.entity;

import java.io.Serializable;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "transport")
public class TransportEntity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4363819747018633743L;
	@Id
	@Column(name = "load_id")
	private String loadId;
	
	@Column(name = "loading_point")
	private String loadingPoint;
	
	@Column(name = "unloading_point")
	private String unloadingPoint;
	
	@Column(name = "loading_date")
	private LocalDate loadingDate;
	
	@Column(name = "unloading_date")
	private LocalDate unloadingDate;
	
	@Column(name = "product_type")
	private String productType;
	
	@Column(name = "truck_type")
	private String truckType;
	
	@Column(name = "no_of_trucks")
	private Integer noOfTrucks;
	
	@Column(name = "weight")
	private Double weight;
	
	@Column(name = "comment")
	private String comment;
	
	@Column(name = "shipper_id")
	private String shipperId;
	
	@Column(name = "date")
	private LocalDate date;

	public String getLoadId() {
		return loadId;
	}

	public void setLoadId(String loadId) {
		this.loadId = loadId;
	}

	public String getLoadingPoint() {
		return loadingPoint;
	}

	public void setLoadingPoint(String loadingPoint) {
		this.loadingPoint = loadingPoint;
	}

	public String getUnloadingPoint() {
		return unloadingPoint;
	}

	public void setUnloadingPoint(String unloadingPoint) {
		this.unloadingPoint = unloadingPoint;
	}

	public LocalDate getLoadingDate() {
		return loadingDate;
	}

	public void setLoadingDate(LocalDate loadingDate) {
		this.loadingDate = loadingDate;
	}

	public LocalDate getUnloadingDate() {
		return unloadingDate;
	}

	public void setUnloadingDate(LocalDate unloadingDate) {
		this.unloadingDate = unloadingDate;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getTruckType() {
		return truckType;
	}

	public void setTruckType(String truckType) {
		this.truckType = truckType;
	}

	public Integer getNoOfTrucks() {
		return noOfTrucks;
	}

	public void setNoOfTrucks(Integer noOfTrucks) {
		this.noOfTrucks = noOfTrucks;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getShipperId() {
		return shipperId;
	}

	public void setShipperId(String shipperId) {
		this.shipperId = shipperId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public TransportEntity() {
		super();
	}

	public TransportEntity(String loadId, String loadingPoint, String unloadingPoint, LocalDate loadingDate,
			LocalDate unloadingDate, String productType, String truckType, Integer noOfTrucks, Double weight,
			String comment, String shipperId, LocalDate date) {
		super();
		this.loadId = loadId;
		this.loadingPoint = loadingPoint;
		this.unloadingPoint = unloadingPoint;
		this.loadingDate = loadingDate;
		this.unloadingDate = unloadingDate;
		this.productType = productType;
		this.truckType = truckType;
		this.noOfTrucks = noOfTrucks;
		this.weight = weight;
		this.comment = comment;
		this.shipperId = shipperId;
		this.date = date;
	}
	
}
