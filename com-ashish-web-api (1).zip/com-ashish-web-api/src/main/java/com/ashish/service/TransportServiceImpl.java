package com.ashish.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.ashish.dto.TransportDTO;
import com.ashish.entity.TransportEntity;
import com.ashish.mapper.TransportMapper;
import com.ashish.repository.TransportRepository;

@Service
public class TransportServiceImpl implements TransportService {

	private TransportRepository transportRepository;

	public TransportServiceImpl(TransportRepository transportRepository) {
		this.transportRepository = transportRepository;
	}

	@Override
	public TransportDTO saveTransport(TransportDTO transportDTO) {
		transportDTO.setLoadId(UUID.randomUUID().toString());
		TransportEntity transportEntity = TransportMapper.mapTransportDTOToTransportEntity(transportDTO);
		return TransportMapper.mapTransportEntityToTransportDTO(transportRepository.save(transportEntity));
	}

	@Override
	public List<TransportDTO> getTransport(String shipperId, String truckType, String productType, String loadingPoint,
			String unloadingPoint) {
		List<TransportEntity> transportEntities = transportRepository
				.findByShipperIdOrTruckTypeOrProductTypeOrLoadingPointOrUnloadingPoint(shipperId, truckType,
						productType, loadingPoint, unloadingPoint);
		List<TransportDTO> transportDTOs = new ArrayList<>();
		if (null != transportEntities) {
			for (TransportEntity transportEntity : transportEntities) {
				transportDTOs.add(TransportMapper.mapTransportEntityToTransportDTO(transportEntity));
			}
		}
		return transportDTOs;
	}

	@Override
	public TransportDTO getTransportById(String loadId) {
		Optional<TransportEntity> optional = transportRepository.findById(loadId);
		if (optional.isPresent()) {
			return TransportMapper.mapTransportEntityToTransportDTO(transportRepository.findById(loadId).get());
		}
		return new TransportDTO();
	}

	@Override
	public TransportDTO updateTransportById(String loadId, TransportDTO transportDTO) {
		if (loadId == transportDTO.getLoadId()) {
			return TransportMapper.mapTransportEntityToTransportDTO(transportRepository.save(TransportMapper.mapTransportDTOToTransportEntity(transportDTO)));
		}else {
			throw new RuntimeException(loadId+" loadId not found");
		}
	}

	@Override
	public void daleteTransportById(String loadId) {
		transportRepository.deleteById(loadId);
	}

}