package com.ashish.service;

import java.util.List;


import com.ashish.dto.TransportDTO;

public interface TransportService {

	public TransportDTO saveTransport(TransportDTO transportEntity);

	public List<TransportDTO> getTransport(String shipperId, String truckType, String productType, String loadingPoint,
			String unloadingPoint);

	public TransportDTO getTransportById(String loadId);

	public TransportDTO updateTransportById(String loadId, TransportDTO transportDTO);

	public void daleteTransportById(String loadId);
}
