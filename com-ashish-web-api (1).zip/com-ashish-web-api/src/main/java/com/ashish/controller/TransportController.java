package com.ashish.controller;

import java.util.List;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ashish.dto.TransportDTO;
import com.ashish.service.TransportService;

@RestController
public class TransportController {

	private TransportService transportService;

	public TransportController(TransportService transportService) {
		this.transportService = transportService;
	}

	@PostMapping("/load")
	public ResponseEntity<TransportDTO> saveTransport(@RequestBody TransportDTO transportDTO) {
		ResponseEntity<TransportDTO> responseEntity = new ResponseEntity<>(transportService.saveTransport(transportDTO),
				HttpStatusCode.valueOf(201));
		return responseEntity;
	}

	@GetMapping("/load")
	public ResponseEntity<List<TransportDTO>> getTransport(@RequestParam String shipperId,
			@RequestParam String truckType, @RequestParam String productType, @RequestParam String loadingPoint,
			@RequestParam String unloadingPoint) {
		return ResponseEntity
				.ok(transportService.getTransport(shipperId, truckType, productType, loadingPoint, unloadingPoint));
	}

	@GetMapping("load/{loadId}")
	public ResponseEntity<TransportDTO> getTransportById(@PathVariable String loadId) {
		return ResponseEntity.ok(transportService.getTransportById(loadId));
	}

	@PutMapping("load/{loadId}")
	public ResponseEntity<TransportDTO> updateTransportById(String loadId, @RequestBody TransportDTO transportDTO) {
		return ResponseEntity.ok(transportService.updateTransportById(loadId, transportDTO));
	}

	@DeleteMapping("load/{loadId}")
	public void daleteTransportById(String loadId) {
		transportService.daleteTransportById(loadId);
	}
}
