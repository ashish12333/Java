package com.ashish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComAshishWebApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComAshishWebApiApplication.class, args);
	}

}
