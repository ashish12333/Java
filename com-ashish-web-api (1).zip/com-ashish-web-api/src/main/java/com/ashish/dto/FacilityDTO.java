/**
 * 
 */
package com.ashish.dto;

import java.io.Serializable;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 
 */
public class FacilityDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8738683477440838381L;
	private String loadingPoint;
	private String unloadingPoint;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	private LocalDate loadingDate;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	private LocalDate unloadingDate;

	public String getLoadingPoint() {
		return loadingPoint;
	}

	public void setLoadingPoint(String loadingPoint) {
		this.loadingPoint = loadingPoint;
	}

	public String getUnloadingPoint() {
		return unloadingPoint;
	}

	public void setUnloadingPoint(String unloadingPoint) {
		this.unloadingPoint = unloadingPoint;
	}

	public LocalDate getLoadingDate() {
		return loadingDate;
	}

	public void setLoadingDate(LocalDate loadingDate) {
		this.loadingDate = loadingDate;
	}

	public LocalDate getUnloadingDate() {
		return unloadingDate;
	}

	public void setUnloadingDate(LocalDate unloadingDate) {
		this.unloadingDate = unloadingDate;
	}

	public FacilityDTO() {
		super();
	}

	public FacilityDTO(String loadingPoint, String unloadingPoint, LocalDate loadingDate, LocalDate unloadingDate) {
		super();
		this.loadingPoint = loadingPoint;
		this.unloadingPoint = unloadingPoint;
		this.loadingDate = loadingDate;
		this.unloadingDate = unloadingDate;
	}

}
